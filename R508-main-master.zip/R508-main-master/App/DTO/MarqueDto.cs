﻿namespace App.DTO
{
    public class MarqueDto
    {
        public int IdMarque { get; set; }
        public string NomMarque { get; set; }
    }
}
