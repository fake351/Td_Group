﻿namespace App.DTO
{
    public class TypeProduitDto
    {
        public int IdTypeProduit { get; set; }
        public string NomTypeProduit { get; set; }
    }
}
