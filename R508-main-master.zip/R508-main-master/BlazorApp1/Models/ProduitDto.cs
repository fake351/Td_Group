﻿namespace BlazorApp.Models
{

    public class ProduitDto
    {
        public int IdProduit { get; set; }
        public string? NomProduit { get; set; }
        public string? Type { get; set; }
        public string? Marque { get; set; }

        public int? StockReel { get; set; }
    }

    

    
}
